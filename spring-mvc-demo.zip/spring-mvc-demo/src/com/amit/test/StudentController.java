package com.amit.test;

import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/student")

	public class StudentController {
		@RequestMapping("/showForm")
		public String showForm(Model theModel) {
			 
			//creating student object
			
		Student1 theStudent = new Student1();
		
		//adding student object to the model
		//you can also write...theModel.addAttribute("student",new Student1())
		theModel.addAttribute("student", theStudent);
		return "student-from";
		}
		
		@RequestMapping("/processForm")
		//validate the input data and check for error
		public String processForm(@Valid @ModelAttribute("student") Student1 theStudent, BindingResult theBindingResult) {
			//log input data
			//System.out.println("Binding Results: " + theBindingResult);
			if(theBindingResult.hasErrors()) {
				//System.out.println("if part...");
			System.out.println("Your Name is : " + theStudent.getFirstName() + " " + theStudent.getLastName());
			
			return "student-from";
		}
			else {
				System.out.println("else part....");
				return "student-confirmation";
				}
			}
			
}
