package com.amit.test;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;


@Controller
public class HelloWorldController {
	@RequestMapping("/showForm")
	public String showForm() {
		return "helloworld-form";	
	}
	@RequestMapping("/prosessForm")
	public String processForm() {
		return "helloworld";
	}
	@RequestMapping("/processFormVersionTwo")
	public String toUpper(HttpServletRequest request, Model model) {
		String theName = request.getParameter("studentName");
		String theName1 = "Welcome " + theName.toUpperCase();
		model.addAttribute("message",theName1);
		return "helloworld";
	}
	@RequestMapping("/processFormVersionThree")
	public String toUpperThree(@RequestParam("studentName") String theName, Model model) {
		String theName1 = "Welcome to homePage " + theName.toUpperCase();
		model.addAttribute("message",theName1);
		return "helloworld";
	}


	
}
