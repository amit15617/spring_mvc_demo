package com.amit.test;

import javax.validation.constraints.Size;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

public class Student1 {
	
	//checking validation...
	@NotNull
	@Size(min=1,message="this field is required")
	private String firstName;
	
	//checking validation...
	@NotNull
	@Size(min=1,message="this field is required")
	private String lastName;
	private String country;
	private String favoriteLanguage;
	private String[] operatingSystems;
	

	//checking validation...
	@Min(value=0,message="experience should be greater than or equal to 0")
	@Max(value=10,message="experience should be lesser than or equal to 10")
	private int experience;
	
	//checking validation...
	@Min(value=18,message="age should be greater than or equal to 18")
	@Max(value=50,message="age should be lesser than or equal to 50")
	private Integer age;
	
	// validate for email check pattern...
	@NotNull
	@Size(min=1,message="this field is required")
	@Pattern(regexp="[A-Za-z0-9._%-+]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}",message="Invalid email format!!!")
	private String Email;
	

	
	
	public Student1() {
		
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getFavoriteLanguage() {
		return favoriteLanguage;
	}
	public void setFavoriteLanguage(String favoriteLanguage) {
		this.favoriteLanguage = favoriteLanguage;
	}
	public String[] getOperatingSystems() {
		return operatingSystems;
	}
	public void setOperatingSystems(String[] operatingSystems) {
		this.operatingSystems = operatingSystems;
	}
	public int getExperience() {
		return experience;
	}
	public void setExperience(int experience) {
		this.experience = experience;
	}
	public Integer getAge() {
		return age;
	}
	public void setAge(Integer age) {
		this.age = age;
	}
	public String getEmail() {
		return Email;
	}
	public void setEmail(String email) {
		Email = email;
	}
	

	
}
